import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { CheckCircle2 } from 'lucide-react';

function ServiceCard({ icon: Icon, title, description, benefits, variant = 'default' }) {
  const cardClasses = {
    default: 'bg-card shadow-lg hover:shadow-xl transition-all duration-300',
    muted: 'bg-muted hover:bg-muted/80 transition-all duration-300',
    accent: 'bg-primary/5 border-primary/20 hover:border-primary/40 transition-all duration-300'
  };

  return (
    <Card className={`${cardClasses[variant]} rounded-2xl`}>
      <CardHeader>
        <div className="flex items-start gap-4">
          <div className="p-3 bg-primary/10 rounded-xl">
            <Icon className="h-6 w-6 text-primary" />
          </div>
          <CardTitle className="text-xl font-semibold">{title}</CardTitle>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-muted-foreground leading-relaxed">{description}</p>
        {benefits && benefits.length > 0 && (
          <ul className="space-y-2">
            {benefits.map((benefit, index) => (
              <li key={index} className="flex items-start gap-2 text-sm">
                <CheckCircle2 className="h-4 w-4 text-accent mt-0.5 flex-shrink-0" />
                <span>{benefit}</span>
              </li>
            ))}
          </ul>
        )}
      </CardContent>
    </Card>
  );
}

export default ServiceCard;