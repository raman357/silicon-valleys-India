import React from 'react';
import { Link } from 'react-router-dom';
import { Mail, Phone, Linkedin, Github, Twitter, MessageCircle } from 'lucide-react';

function Footer() {
  const serviceLinks = [
    { path: '/services', label: 'Schematics Design' },
    { path: '/services', label: 'PCB Layout' },
    { path: '/services', label: 'Manufacturing Support' },
    { path: '/services', label: 'PCB Assembly' }
  ];

  const companyLinks = [
    { path: '/about', label: 'About Us' },
    { path: '/portfolio', label: 'Portfolio' },
    { path: '/contact', label: 'Contact' }
  ];

  return (
    <footer className="bg-slate-900 text-slate-100 border-t border-slate-800">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="md:col-span-2">
            <span className="text-lg font-bold">Silicon Valleys India</span>
            <p className="mt-4 text-sm text-slate-300 max-w-md">
              Professional electronics design services from concept to production. We deliver high-quality PCB design, testing, and certification support for your next project.
            </p>
            <div className="flex gap-4 mt-6">
              <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer" className="text-slate-400 hover:text-primary transition-colors duration-200">
                <Linkedin className="h-5 w-5" />
              </a>
              <a href="https://github.com" target="_blank" rel="noopener noreferrer" className="text-slate-400 hover:text-primary transition-colors duration-200">
                <Github className="h-5 w-5" />
              </a>
              <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" className="text-slate-400 hover:text-primary transition-colors duration-200">
                <Twitter className="h-5 w-5" />
              </a>
            </div>
          </div>

          {/* Services */}
          <div>
            <span className="font-semibold text-sm tracking-wide uppercase">Services</span>
            <ul className="mt-4 space-y-2">
              {serviceLinks.map((link, index) => (
                <li key={index}>
                  <Link to={link.path} className="text-sm text-slate-300 hover:text-primary transition-colors duration-200">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Company */}
          <div>
            <span className="font-semibold text-sm tracking-wide uppercase">Company</span>
            <ul className="mt-4 space-y-2">
              {companyLinks.map((link, index) => (
                <li key={index}>
                  <Link to={link.path} className="text-sm text-slate-300 hover:text-primary transition-colors duration-200">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
            <div className="mt-6 space-y-3">
              <div className="flex items-center gap-2 text-sm text-slate-300">
                <Mail className="h-4 w-4 flex-shrink-0" />
                <a href="mailto:ry0078092@gmail.com" className="hover:text-primary transition-colors duration-200">
                  ry0078092@gmail.com
                </a>
              </div>
              <div className="flex items-center gap-2 text-sm text-slate-300">
                <Phone className="h-4 w-4 flex-shrink-0" />
                <a href="tel:+919067649481" className="hover:text-primary transition-colors duration-200">
                  +91 9067649481
                </a>
              </div>
              <div className="flex items-center gap-2 text-sm text-slate-300">
                <MessageCircle className="h-4 w-4 flex-shrink-0" />
                <a href="https://wa.me/919067649481" target="_blank" rel="noopener noreferrer" className="hover:text-primary transition-colors duration-200">
                  WhatsApp
                </a>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-slate-800 flex flex-col sm:flex-row justify-between items-center gap-4">
          <p className="text-sm text-slate-400">
            © 2026 Silicon Valleys India. All rights reserved.
          </p>
          <div className="flex gap-6 text-sm text-slate-400">
            <Link to="/privacy" className="hover:text-primary transition-colors duration-200">Privacy Policy</Link>
            <Link to="/terms" className="hover:text-primary transition-colors duration-200">Terms of Service</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}

export default Footer;