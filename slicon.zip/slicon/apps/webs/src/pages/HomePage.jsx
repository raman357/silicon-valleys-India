import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowRight, Cpu, Layers, Wrench, TestTube, Shield, CheckCircle, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import ServiceCard from '@/components/ServiceCard.jsx';

function HomePage() {
  const services = [
    {
      icon: Cpu,
      title: 'Schematics Design',
      description: 'Professional circuit design with industry-standard tools and best practices.',
      variant: 'default'
    },
    {
      icon: Layers,
      title: 'PCB Layout Design',
      description: 'Multi-layer PCB layouts optimized for signal integrity and manufacturability.',
      variant: 'muted'
    },
    {
      icon: Wrench,
      title: 'Manufacturing Support',
      description: 'Complete DFM analysis and manufacturing documentation preparation.',
      variant: 'default'
    },
    {
      icon: Zap,
      title: 'PCB Assembly',
      description: 'High-quality assembly services with automated and manual processes.',
      variant: 'accent'
    },
    {
      icon: TestTube,
      title: 'Testing & Debugging',
      description: 'Comprehensive PCBA testing and systematic debugging procedures.',
      variant: 'muted'
    },
    {
      icon: Shield,
      title: 'EMI/EMC Certification',
      description: 'Testing and certification support for electromagnetic compliance.',
      variant: 'default'
    },
    {
      icon: CheckCircle,
      title: 'Product Validation',
      description: 'End-to-end validation ensuring your product meets all specifications.',
      variant: 'muted'
    }
  ];

  return (
    <>
      <Helmet>
        <title>Silicon Valleys India - Electronics Design & Development Services</title>
        <meta name="description" content="Silicon Valleys India provides expert electronics design services from schematics to production. PCB design, assembly, testing, and certification support for your next project." />
      </Helmet>

      <div className="min-h-screen flex flex-col">
        <Header />

        {/* Hero Section */}
        <section className="relative min-h-[100dvh] flex items-center justify-center overflow-hidden">
          <div 
            className="absolute inset-0 z-0"
            style={{
              backgroundImage: 'url(https://images.unsplash.com/photo-1532186773960-85649e5cb70b)',
              backgroundSize: 'cover',
              backgroundPosition: 'center'
            }}
          >
            <div className="absolute inset-0 bg-gradient-to-br from-slate-900/95 via-slate-900/90 to-primary/20" />
          </div>

          <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="max-w-4xl mx-auto text-center"
            >
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6" style={{ letterSpacing: '-0.02em' }}>
                Silicon Valleys India transforms your electronics vision into reality
              </h1>
              <p className="text-xl md:text-2xl text-slate-200 mb-8 leading-relaxed max-w-3xl mx-auto">
                From initial schematics to final production, Silicon Valleys India delivers precision engineering with speed, quality, and innovation at every step.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link to="/contact">
                  <Button size="lg" className="text-lg px-8 group">
                    Get Started with Silicon Valleys India
                    <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform duration-200" />
                  </Button>
                </Link>
                <Link to="/services">
                  <Button size="lg" variant="outline" className="text-lg px-8 bg-white/10 backdrop-blur-sm border-white/20 text-white hover:bg-white/20">
                    View Services
                  </Button>
                </Link>
              </div>

              <div className="grid grid-cols-3 gap-8 mt-16 max-w-2xl mx-auto">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.2 }}
                  className="text-center"
                >
                  <div className="text-3xl md:text-4xl font-bold text-accent mb-2">47%</div>
                  <div className="text-sm text-slate-300">Faster turnaround</div>
                </motion.div>
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.3 }}
                  className="text-center"
                >
                  <div className="text-3xl md:text-4xl font-bold text-accent mb-2">2,847</div>
                  <div className="text-sm text-slate-300">Projects delivered</div>
                </motion.div>
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.4 }}
                  className="text-center"
                >
                  <div className="text-3xl md:text-4xl font-bold text-accent mb-2">98.7%</div>
                  <div className="text-sm text-slate-300">Client satisfaction</div>
                </motion.div>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Services Overview */}
        <section className="py-20 bg-background">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className="text-center mb-12"
            >
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Silicon Valleys India's complete electronics design services</h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                End-to-end solutions covering every phase of your electronics development lifecycle
              </p>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {services.map((service, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                >
                  <ServiceCard {...service} />
                </motion.div>
              ))}
            </div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.7 }}
              className="text-center mt-12"
            >
              <Link to="/services">
                <Button size="lg" variant="outline">
                  View All Services
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
            </motion.div>
          </div>
        </section>

        <Footer />
      </div>
    </>
  );
}

export default HomePage;