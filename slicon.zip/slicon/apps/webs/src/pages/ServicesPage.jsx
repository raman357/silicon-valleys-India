import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Cpu, Layers, Wrench, Zap, TestTube, Shield, CheckCircle } from 'lucide-react';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import ServiceCard from '@/components/ServiceCard.jsx';

function ServicesPage() {
  const services = [
    {
      icon: Cpu,
      title: 'Schematics Design',
      description: 'Professional circuit design using industry-standard tools like Altium Designer, KiCad, and Eagle. We create detailed schematics that form the foundation of your electronic product.',
      benefits: [
        'Component selection and optimization',
        'Design rule checking and validation',
        'Bill of materials generation',
        'Design documentation and reports'
      ],
      variant: 'default'
    },
    {
      icon: Layers,
      title: 'PCB Layout Design',
      description: 'Multi-layer PCB layouts optimized for signal integrity, power distribution, and thermal management. Our designs are manufacturing-ready and cost-effective.',
      benefits: [
        'High-speed signal routing',
        'Impedance control and matching',
        'EMI/EMC considerations',
        'Design for manufacturing (DFM)'
      ],
      variant: 'muted'
    },
    {
      icon: Wrench,
      title: 'PCB Manufacturing Support',
      description: 'Complete manufacturing support including DFM analysis, Gerber file generation, and fabrication documentation. We ensure your design is production-ready.',
      benefits: [
        'Gerber and drill file generation',
        'Manufacturing documentation',
        'Vendor liaison and support',
        'Cost optimization strategies'
      ],
      variant: 'accent'
    },
    {
      icon: Zap,
      title: 'PCB Assembly',
      description: 'High-quality assembly services with both automated SMT and manual through-hole processes. We handle prototypes to production volumes.',
      benefits: [
        'Surface mount technology (SMT)',
        'Through-hole assembly',
        'Conformal coating application',
        'Quality inspection and testing'
      ],
      variant: 'default'
    },
    {
      icon: TestTube,
      title: 'PCBA Testing and Debugging',
      description: 'Comprehensive testing procedures including functional testing, in-circuit testing, and systematic debugging to ensure product reliability.',
      benefits: [
        'Functional testing protocols',
        'In-circuit testing (ICT)',
        'Boundary scan testing',
        'Root cause analysis'
      ],
      variant: 'muted'
    },
    {
      icon: Shield,
      title: 'EMI/EMC Testing and Certification Support',
      description: 'Pre-compliance testing and certification support for electromagnetic interference and compatibility standards including FCC, CE, and industry-specific requirements.',
      benefits: [
        'Pre-compliance testing',
        'Design modifications for compliance',
        'Test lab coordination',
        'Certification documentation'
      ],
      variant: 'default'
    },
    {
      icon: CheckCircle,
      title: 'Product Validation',
      description: 'End-to-end validation ensuring your product meets all functional, performance, and regulatory specifications before mass production.',
      benefits: [
        'Environmental testing',
        'Reliability testing',
        'Performance validation',
        'Compliance verification'
      ],
      variant: 'accent'
    }
  ];

  return (
    <>
      <Helmet>
        <title>Silicon Valleys India - Electronics Design & Development Services</title>
        <meta name="description" content="Silicon Valleys India offers comprehensive electronics design services including schematics, PCB layout, assembly, testing, and certification support." />
      </Helmet>

      <div className="min-h-screen flex flex-col">
        <Header />

        <main className="flex-1">
          {/* Hero Section */}
          <section className="bg-gradient-to-br from-primary/10 via-background to-accent/5 py-20">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
                className="max-w-3xl mx-auto text-center"
              >
                <h1 className="text-4xl md:text-5xl font-bold mb-6" style={{ letterSpacing: '-0.02em' }}>
                  Silicon Valleys India's professional electronics design services
                </h1>
                <p className="text-xl text-muted-foreground leading-relaxed">
                  From concept to production, Silicon Valleys India provides comprehensive solutions for all your electronics development needs
                </p>
              </motion.div>
            </div>
          </section>

          {/* Services Grid */}
          <section className="py-20">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {services.map((service, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                  >
                    <ServiceCard {...service} />
                  </motion.div>
                ))}
              </div>
            </div>
          </section>
        </main>

        <Footer />
      </div>
    </>
  );
}

export default ServicesPage;