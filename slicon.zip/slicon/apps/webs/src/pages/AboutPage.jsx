import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Award, Users, Target, Lightbulb } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';

function AboutPage() {
  const values = [
    {
      icon: Award,
      title: 'Quality excellence',
      description: 'We maintain the highest standards in every project, ensuring reliable and robust electronic designs.'
    },
    {
      icon: Users,
      title: 'Client partnership',
      description: 'Your success is our success. We work closely with clients to understand and exceed their expectations.'
    },
    {
      icon: Target,
      title: 'Precision engineering',
      description: 'Attention to detail in every schematic, layout, and assembly ensures optimal product performance.'
    },
    {
      icon: Lightbulb,
      title: 'Innovation driven',
      description: 'We stay current with emerging technologies and methodologies to deliver cutting-edge solutions.'
    }
  ];

  const expertise = [
    'High-speed digital design',
    'Analog and mixed-signal circuits',
    'Power electronics',
    'RF and wireless systems',
    'Embedded systems',
    'IoT device development'
  ];

  return (
    <>
      <Helmet>
        <title>Silicon Valleys India - About Us</title>
        <meta name="description" content="Learn about Silicon Valleys India, our team, expertise, and commitment to delivering exceptional electronics design services." />
      </Helmet>

      <div className="min-h-screen flex flex-col">
        <Header />

        <main className="flex-1">
          {/* Hero Section */}
          <section className="bg-gradient-to-br from-primary/10 via-background to-accent/5 py-20">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
                className="max-w-3xl mx-auto text-center"
              >
                <h1 className="text-4xl md:text-5xl font-bold mb-6" style={{ letterSpacing: '-0.02em' }}>
                  Silicon Valleys India: Building the future of electronics
                </h1>
                <p className="text-xl text-muted-foreground leading-relaxed">
                  A team of experienced engineers dedicated to transforming innovative ideas into production-ready electronic products
                </p>
              </motion.div>
            </div>
          </section>

          {/* Company Story */}
          <section className="py-20">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6 }}
                >
                  <h2 className="text-3xl md:text-4xl font-bold mb-6">About Silicon Valleys India</h2>
                  <div className="space-y-4 text-muted-foreground leading-relaxed">
                    <p>
                      Silicon Valleys India is a professional electronics design and development company founded with a vision to bridge the gap between innovative concepts and market-ready electronic products. Our team brings together decades of combined experience in circuit design, PCB layout, embedded systems, and regulatory compliance.
                    </p>
                    <p>
                      We serve clients across diverse industries including medical devices, industrial automation, consumer electronics, and automotive systems. Silicon Valleys India has successfully delivered over 2,800 projects, from simple prototypes to complex multi-board systems, earning a reputation as a trusted partner for startups and established companies alike.
                    </p>
                    <p>
                      Our commitment to quality, innovation, and client success drives everything we do. At Silicon Valleys India, we believe that exceptional electronics design requires precision, dedication, and a deep understanding of our clients' unique challenges and goals.
                    </p>
                  </div>
                </motion.div>

                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6 }}
                  className="relative"
                >
                  <img
                    src="https://horizons-cdn.hostinger.com/40698930-345f-4cea-ae74-383bdb84657e/9f467cd5175831b24636cbacd03171eb.jpg"
                    alt="Professional hardware design engineer working at desk with PCB design displayed on computer monitor"
                    className="rounded-2xl shadow-2xl w-full"
                  />
                </motion.div>
              </div>
            </div>
          </section>

          {/* Expertise */}
          <section className="py-20 bg-muted/30">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5 }}
                className="text-center mb-12"
              >
                <h2 className="text-3xl md:text-4xl font-bold mb-4">Silicon Valleys India's core expertise</h2>
                <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                  Our team specializes in diverse areas of electronics design and development
                </p>
              </motion.div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-4xl mx-auto">
                {expertise.map((item, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                  >
                    <Card className="bg-card shadow-md hover:shadow-lg transition-all duration-300">
                      <CardContent className="p-6">
                        <p className="font-medium text-center">{item}</p>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </div>
          </section>

          {/* Values */}
          <section className="py-20">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5 }}
                className="text-center mb-12"
              >
                <h2 className="text-3xl md:text-4xl font-bold mb-4">Silicon Valleys India's values</h2>
                <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                  The principles that guide our work and relationships with clients
                </p>
              </motion.div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {values.map((value, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                  >
                    <Card className="bg-card shadow-lg hover:shadow-xl transition-all duration-300 rounded-2xl">
                      <CardContent className="p-8">
                        <div className="flex items-start gap-4">
                          <div className="p-3 bg-primary/10 rounded-xl">
                            <value.icon className="h-6 w-6 text-primary" />
                          </div>
                          <div>
                            <h3 className="text-xl font-semibold mb-2">{value.title}</h3>
                            <p className="text-muted-foreground leading-relaxed">{value.description}</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </div>
          </section>
        </main>

        <Footer />
      </div>
    </>
  );
}

export default AboutPage;