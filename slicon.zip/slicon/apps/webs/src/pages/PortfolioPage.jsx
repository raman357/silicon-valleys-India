import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import ProjectCard from '@/components/ProjectCard.jsx';

function PortfolioPage() {
  const projects = [
    {
      image: 'https://images.unsplash.com/photo-1518770660439-4636190af475',
      title: 'Industrial IoT Sensor Node',
      description: 'Multi-sensor data acquisition system with LoRaWAN connectivity for industrial monitoring applications. Features ultra-low power consumption and IP67 enclosure rating.',
      technologies: ['STM32', 'LoRaWAN', 'I2C Sensors', '4-layer PCB'],
      metric: '83% reduction in power consumption'
    },
    {
      image: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d',
      title: 'Medical Device Controller',
      description: 'FDA-compliant embedded controller for medical diagnostic equipment. Implemented safety-critical firmware with redundant monitoring systems.',
      technologies: ['ARM Cortex-M7', 'IEC 60601', 'CAN Bus', 'Safety Critical'],
      metric: 'FDA 510(k) clearance achieved'
    },
    {
      image: 'https://images.unsplash.com/photo-1593941707882-a5bba14938c7',
      title: 'Automotive ECU Module',
      description: 'Electronic control unit for automotive applications with CAN/LIN interfaces. Designed to meet AEC-Q100 qualification standards.',
      technologies: ['Infineon AURIX', 'CAN/LIN', 'AUTOSAR', 'EMC Certified'],
      metric: '47% faster processing speed'
    },
    {
      image: 'https://images.unsplash.com/photo-1523475496153-3d6cc0f0bf19',
      title: 'Consumer Wearable Device',
      description: 'Compact wearable health tracker with BLE connectivity and advanced power management. Achieved 14-day battery life in a slim form factor.',
      technologies: ['nRF52840', 'BLE 5.0', 'Flex PCB', 'Li-Po Battery'],
      metric: '14-day battery life achieved'
    },
    {
      image: 'https://images.unsplash.com/photo-1509391366360-2e959784a276',
      title: 'Renewable Energy Inverter',
      description: 'High-efficiency solar inverter with MPPT control and grid-tie capability. Designed for residential and commercial installations.',
      technologies: ['DSP Control', 'SiC MOSFETs', 'Grid-Tie', 'UL Certified'],
      metric: '96.2% conversion efficiency'
    }
  ];

  return (
    <>
      <Helmet>
        <title>Silicon Valleys India - Portfolio</title>
        <meta name="description" content="Explore Silicon Valleys India's portfolio of successful electronics design projects across industries including IoT, medical devices, automotive, and consumer electronics." />
      </Helmet>

      <div className="min-h-screen flex flex-col">
        <Header />

        <main className="flex-1">
          {/* Hero Section */}
          <section className="bg-gradient-to-br from-primary/10 via-background to-accent/5 py-20">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
                className="max-w-3xl mx-auto text-center"
              >
                <h1 className="text-4xl md:text-5xl font-bold mb-6" style={{ letterSpacing: '-0.02em' }}>
                  Silicon Valleys India's portfolio
                </h1>
                <p className="text-xl text-muted-foreground leading-relaxed">
                  Successful projects delivered across diverse industries, from concept to production
                </p>
              </motion.div>
            </div>
          </section>

          {/* Projects Grid */}
          <section className="py-20">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {projects.map((project, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                  >
                    <ProjectCard {...project} />
                  </motion.div>
                ))}
              </div>
            </div>
          </section>

          {/* CTA Section */}
          <section className="py-20 bg-muted/30">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5 }}
                className="max-w-3xl mx-auto text-center"
              >
                <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to start your project with Silicon Valleys India?</h2>
                <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
                  Let Silicon Valleys India help you bring your electronics design vision to life with our proven expertise and comprehensive services.
                </p>
                <Link to="/contact">
                  <button className="bg-primary text-primary-foreground px-8 py-3 rounded-lg font-medium hover:bg-primary/90 transition-all duration-200 active:scale-[0.98]">
                    Get in Touch with Silicon Valleys India
                  </button>
                </Link>
              </motion.div>
            </div>
          </section>
        </main>

        <Footer />
      </div>
    </>
  );
}

export default PortfolioPage;