import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Mail, Phone, MapPin, Clock, MessageCircle } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import ContactForm from '@/components/ContactForm.jsx';

function ContactPage() {
  const contactInfo = [
    {
      icon: Mail,
      title: 'Email',
      content: 'ry0078092@gmail.com',
      link: 'mailto:ry0078092@gmail.com'
    },
    {
      icon: Phone,
      title: 'Phone',
      content: '+91 9067649481',
      link: 'tel:+919067649481'
    },
    {
      icon: MessageCircle,
      title: 'WhatsApp',
      content: '+91 9067649481',
      link: 'https://wa.me/919067649481'
    },
    {
      icon: MapPin,
      title: 'Location',
      content: 'Mumbai, India',
      link: null
    },
    {
      icon: Clock,
      title: 'Business Hours',
      content: 'Mon-Fri: 9:00 AM - 6:00 PM IST',
      link: null
    }
  ];

  return (
    <>
      <Helmet>
        <title>Silicon Valleys India - Contact Us</title>
        <meta name="description" content="Get in touch with Silicon Valleys India's electronics design team. Request a quote or discuss your project requirements." />
      </Helmet>

      <div className="min-h-screen flex flex-col">
        <Header />

        <main className="flex-1">
          {/* Hero Section */}
          <section className="bg-gradient-to-br from-primary/10 via-background to-accent/5 py-20">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
                className="max-w-3xl mx-auto text-center"
              >
                <h1 className="text-4xl md:text-5xl font-bold mb-6" style={{ letterSpacing: '-0.02em' }}>
                  Get in touch with Silicon Valleys India
                </h1>
                <p className="text-xl text-muted-foreground leading-relaxed">
                  Ready to start your electronics design project? Contact Silicon Valleys India today to discuss your requirements and get a detailed quote.
                </p>
              </motion.div>
            </div>
          </section>

          {/* Contact Section */}
          <section className="py-20">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
                {/* Contact Form */}
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6 }}
                >
                  <ContactForm />
                </motion.div>

                {/* Contact Information */}
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6 }}
                  className="space-y-8"
                >
                  <div>
                    <h2 className="text-2xl font-semibold mb-4">Silicon Valleys India contact information</h2>
                    <p className="text-muted-foreground leading-relaxed mb-8">
                      The Silicon Valleys India team is ready to assist you with your electronics design needs. Reach out through any of the channels below.
                    </p>
                  </div>

                  <div className="space-y-4">
                    {contactInfo.map((info, index) => (
                      <Card key={index} className="bg-muted/50 hover:bg-muted transition-all duration-200">
                        <CardContent className="p-6">
                          <div className="flex items-start gap-4">
                            <div className="p-3 bg-primary/10 rounded-xl">
                              <info.icon className="h-5 w-5 text-primary" />
                            </div>
                            <div>
                              <h3 className="font-semibold mb-1">{info.title}</h3>
                              {info.link ? (
                                <a 
                                  href={info.link}
                                  target={info.title === 'WhatsApp' ? '_blank' : undefined}
                                  rel={info.title === 'WhatsApp' ? 'noopener noreferrer' : undefined}
                                  className="text-muted-foreground hover:text-primary transition-colors duration-200"
                                >
                                  {info.content}
                                </a>
                              ) : (
                                <p className="text-muted-foreground">{info.content}</p>
                              )}
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>

                  <Card className="bg-primary/5 border-primary/20">
                    <CardContent className="p-6">
                      <h3 className="font-semibold mb-2">Silicon Valleys India quick response guarantee</h3>
                      <p className="text-sm text-muted-foreground leading-relaxed">
                        Silicon Valleys India typically responds to all inquiries within 24 hours during business days. For urgent matters, please call or message us directly via WhatsApp.
                      </p>
                    </CardContent>
                  </Card>
                </motion.div>
              </div>
            </div>
          </section>
        </main>

        <Footer />
      </div>
    </>
  );
}

export default ContactPage;