
import {Routes,Route,Link} from 'react-router-dom';
const Layout=({title})=><div style={{fontFamily:'Arial',padding:'40px'}}>
<nav><Link to='/'>Home</Link> | <Link to='/services'>Services</Link> | <Link to='/about'>About</Link> | <Link to='/portfolio'>Portfolio</Link> | <Link to='/contact'>Contact</Link></nav>
<h1>{title}</h1><p>Silicon Valleys India - Electronics Design Services</p></div>;
export default function App(){return <Routes>
<Route path='/' element={<Layout title='Home'/>}/>
<Route path='/services' element={<Layout title='Services'/>}/>
<Route path='/about' element={<Layout title='About Us'/>}/>
<Route path='/portfolio' element={<Layout title='Portfolio'/>}/>
<Route path='/contact' element={<Layout title='Contact'/>}/>
</Routes>}
